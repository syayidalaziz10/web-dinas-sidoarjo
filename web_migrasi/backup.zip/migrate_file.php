<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Move Images</title>

</head>

<body>

    <h2>Pindahkan Gambar</h2>
    <p>Klik tombol di bawah ini untuk memindahkan gambar.</p>
       <form method="POST">
        <input type="submit" class="btn btn-primary" name="move_image" value="Migrate Image">
    </form>
    <?php
        function move_image($folder_asal, $folder_tujuan) {
            
            $files = glob($folder_asal . '/*.{jpg,jpeg,png,gif,pdf,docs}', GLOB_BRACE);
            
            foreach ($files as $file) {
                $nama_file = basename($file);
                if (copy($file, $folder_tujuan.'/'.$nama_file)) {
                    echo "File ".$nama_file." berhasil dipindahkan dan dicopy.<br>";
                } else {
                    echo "Gagal memindahkan file ".$nama_file.".<br>";
                }
            }
        }
    
        $_dirPost	= 'images/post'; //POST
        $_dirEmp	= 'images/employees'; //EMP
        $_dirLHKPN	= 'images/lhkpn'; //LHKPN
        $_dirKategori = 'images/kategori'; //KATEGORY
        $_dirGalery = 'images/galery'; //GALERY & BANNER
        $_dirFiles = 'images/files';//FILES PENGUMUMAN
        $_dirProf = 'images/prof';//PROFIL
        $_dirLink	= 'images/socials'; //SOSMED

    
        if (isset($_POST['move_image'])) {
            
            $folder_move = array(
                // banners
                array('web_old/images/uploads/banners', $_dirGalery),
                array('web_old/images/uploads/prestasi', $_dirGalery),
                // end banner
    
                // employess
                array('web_old/images/uploads/employees', $_dirEmp),
                array('web_old/images/uploads/leaders', $_dirEmp),
                // end employess
    
                // post
                array('web_old/images/uploads/events', $_dirPost),
                array('web_old/images/uploads/news', $_dirPost),
                // end post
    
                // socials
                array('web_old/images/uploads/inst', $_dirLink),
                // end socials
    
                // files
                array('web_old/downloads', $_dirFiles)
    
                // end files
            );
    
            foreach ($folder_move as $folder_mv) {
                move_image($folder_mv[0], $folder_mv[1]);
            }
        }
    ?>
 
</body>

</html>